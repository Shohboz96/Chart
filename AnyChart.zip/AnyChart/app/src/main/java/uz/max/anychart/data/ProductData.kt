package uz.max.anychart.data

data class ProductData(
    val modelName: String,
    val serial: String,
    val manufacturer: String
)