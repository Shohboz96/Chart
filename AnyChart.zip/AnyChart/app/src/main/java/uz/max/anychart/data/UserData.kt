package uz.max.anychart.data

data class UserData(
    var age: Int,
    val lastName: String,
    val firstName: String
)